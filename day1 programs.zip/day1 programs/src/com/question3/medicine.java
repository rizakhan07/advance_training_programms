package com.question3;

public class medicine {
	public void displayLabel(){
		System.out.println("Company : opolo pharmacy");
		System.out.println("Address : cowl bazar beside police station");
	}
}
class Tablet extends medicine{
		 
	public void displayLabel(){
		System.out.println("store in a cool dry place");
		}
	}
class Syrup extends medicine{
	public void displayLabel(){
		System.out.println("Consumption as directed by thephysician");
		}
		}
class Ointment extends medicine{
	public void displayLabel(){
		System.out.println("for external use only");
		}

}
