package com.question1;

public class Rectangle_Modify_Test {


    public static void main(String args[]) {
    	
        Rectangle_Modify obj1 = new Rectangle_Modify();
        obj1.input();
        obj1.areaRectangle();
        obj1.perimeterRectangle();
        obj1.display();
        System.out.println("object 2");
        Rectangle_Modify obj2 = new Rectangle_Modify();
        obj2.input();
        obj2.areaRectangle();
        obj2.perimeterRectangle();
        obj2.display();
        System.out.println("object 3");
        Rectangle_Modify obj3 = new Rectangle_Modify();
        obj3.input();
        obj3.areaRectangle();
        obj3.perimeterRectangle();
        obj3.display();
        System.out.println("object 4");
        Rectangle_Modify obj4 = new Rectangle_Modify();
        obj4.input();
        obj4.areaRectangle();
        obj4.perimeterRectangle();
        obj4.display();
        System.out.println("object 5");
        Rectangle_Modify obj5 = new Rectangle_Modify();
        obj5.input();
        obj5.areaRectangle();
        obj5.perimeterRectangle();
        obj5.display();
    	
    }


}
