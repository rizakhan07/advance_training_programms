package com.question1;
import java.util.Scanner;
public class even_numbers {
	public static void main(String[] args) {
		int n=0,i;
		Scanner a=new Scanner(System.in);
		System.out.println("Enter the number:");
		n=a.nextInt();
		
		for(i=1;i<=n;i++) {
			if(i%2==0) {
			System.out.println(i);	
			}
				
		}
	}

}
