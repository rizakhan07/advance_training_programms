package com.question6;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;


public class student_finding {
	/*public static void main (String[] args){
		 ArrayList<String> a1=new ArrayList<String>();
	 int n;
	 Scanner sc= new Scanner(System.in);
	 System.out.println("enter the number of students:");
	 n=sc.nextInt();
	 System.out.println("enter the student names:");
	for(int i=0;i<n;i++)
	{
		a1.add(sc.next());
	}
	System.out.println("student list:");
	for(String a:a1)
	{
			System.out.println("enter the name of the student to be searched:");
		    String st=sc.next(); 
		    int position=Collections.binarySearch(a1,st);
			System.out.println("posistion of"+st+"is:"+position);
			
			}
	 }*/
	public static void main(String[] args) {
		ArrayList<String> alist=new ArrayList<String>();//Creating arraylist  
	    alist.add("raja");//Adding object in arraylist  
	    alist.add("rani");  
	    alist.add("mantri");  
	    alist.add("police");
	    alist.add("dasi");
	    alist.add("chor");
	    System.out.println(alist);
	    
	    if (alist.contains("Raavi"))
	        System.out.println("Raavi exists in the ArrayList");

	    else
	        System.out.println("Raavi does not exist in the ArrayList");

	    if (alist.contains("dasi"))
	        System.out.println("Priya exists in the ArrayList");

	    else
	        System.out.println("Priya does not exist in the ArrayList");
	    
	}

}
